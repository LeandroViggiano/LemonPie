
var variable1= "hola"; /*puede cambiar de string a int, por ejemplo */
let variable2; /*Puede cambiar su valor pero no su tipo de dato, siempre int o string */
const variable3=1; /*Nunca cambia nada*/
function name(params) {
    
}
console.log("Hola Mundo!");